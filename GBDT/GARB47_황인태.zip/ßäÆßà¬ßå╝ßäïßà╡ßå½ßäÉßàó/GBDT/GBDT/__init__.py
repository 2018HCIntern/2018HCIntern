'''

	GBDT+LR
	~~~~~~~

	:copyright: Intae Whoang

'''

__version__ = '1.0'

