GBDT\.GBDT module
=================

.. automodule:: GBDT.GBDT
    :members:
    :undoc-members:
    :show-inheritance:
