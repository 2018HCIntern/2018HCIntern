import code.main
code.main.mainRun()
